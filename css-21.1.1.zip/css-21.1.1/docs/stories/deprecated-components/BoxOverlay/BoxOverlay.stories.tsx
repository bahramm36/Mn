import React from 'react'
import {BADGE} from '@geometricpanda/storybook-addon-badges'

export default {
  title: 'Deprecated/BoxOverlay',
  parameters: {
    storyType: 'banner',
    controls: {hideNoControlsWarning: true},
    badges: [BADGE.DEPRECATED],
  },
}

export const Default = () => {
  return (
    <details className="details-reset details-overlay details-overlay-dark">
      <summary className="btn" aria-haspopup="dialog">
        Open dialog
      </summary>
      <details-dialog className="Box Box--overlay d-flex flex-column anim-fade-in fast">
        <div className="Box-header">
          <button
            className="Box-btn-octicon btn-octicon float-right"
            type="button"
            aria-label="Close dialog"
            data-close-dialog
          >
            <svg
              className="octicon octicon-x"
              viewBox="0 0 12 16"
              version="1.1"
              width="12"
              height="16"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"
              ></path>
            </svg>
          </button>
          <h3 className="Box-title">Box title</h3>
        </div>
        <div className="overflow-auto">
          <div className="Box-body overflow-auto">
            <p>
              The quick brown fox jumps over the lazy dog and feels as if he were in the seventh heaven of typography
              together with Hermann Zapf, the most famous artist of the...
            </p>
          </div>
          <ul>
            <li className="Box-row">
              <img
                className="avatar v-align-middle mr-2"
                src="https://avatars.githubusercontent.com/broccolini?s=48"
                alt="broccolini"
                width="24"
                height="24"
              />
              @broccolini
            </li>
            <li className="Box-row border-bottom">
              <img
                className="avatar v-align-middle mr-2"
                src="https://avatars.githubusercontent.com/jonrohan?s=48"
                alt="jonrohan"
                width="24"
                height="24"
              />
              @jonrohan
            </li>
            <li className="Box-row border-bottom">
              <img
                className="avatar v-align-middle mr-2"
                src="https://avatars.githubusercontent.com/shawnbot?s=48"
                alt="shawnbot"
                width="24"
                height="24"
              />
              @shawnbot
            </li>
          </ul>
        </div>
        <div className="Box-footer">
          <button type="button" className="btn btn-block" data-close-dialog>
            Okidoki
          </button>
        </div>
      </details-dialog>
    </details>
  )
}
