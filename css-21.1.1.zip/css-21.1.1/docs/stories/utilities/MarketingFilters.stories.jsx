export default {
  title: 'Utilities/Marketing/Filters',
}

export const Grayscale = ({}) => (
  <>
    <img src="https://github.com/probot.png" class="img-responsive grayscale" alt="" />
  </>
)
